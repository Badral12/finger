__DEPRECATED__

This directory is deprecated and no longer accepting pull requests.

There are many ways to connect to the
[TensorFlow community](https://www.tensorflow.org/community) including
[SIG projects](https://github.com/tensorflow/community/tree/master/sigs) and
[ML GDE initiatives](https://github.com/ml-gde).
